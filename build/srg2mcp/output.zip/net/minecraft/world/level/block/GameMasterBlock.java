package net.minecraft.world.level.block;

public interface GameMasterBlock {
}