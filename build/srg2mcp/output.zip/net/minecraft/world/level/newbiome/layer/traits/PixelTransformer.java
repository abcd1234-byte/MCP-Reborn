package net.minecraft.world.level.newbiome.layer.traits;

public interface PixelTransformer {
   int apply(int pX, int pZ);
}