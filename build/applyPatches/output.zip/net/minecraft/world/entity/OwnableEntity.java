package net.minecraft.world.entity;

import java.util.UUID;
import javax.annotation.Nullable;

public interface OwnableEntity {
   @Nullable
   UUID m_142504_();

   @Nullable
   Entity m_142480_();
}