package net.minecraft.world;

public interface SnooperPopulator {
   void m_7108_(Snooper p_19234_);

   void m_142423_(Snooper p_146683_);

   boolean m_142725_();
}