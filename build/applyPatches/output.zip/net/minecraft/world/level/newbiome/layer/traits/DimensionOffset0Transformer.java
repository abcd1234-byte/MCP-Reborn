package net.minecraft.world.level.newbiome.layer.traits;

public interface DimensionOffset0Transformer extends DimensionTransformer {
   default int m_6320_(int p_77066_) {
      return p_77066_;
   }

   default int m_6317_(int p_77068_) {
      return p_77068_;
   }
}