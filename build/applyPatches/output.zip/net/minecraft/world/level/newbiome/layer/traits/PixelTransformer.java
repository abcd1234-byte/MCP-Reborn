package net.minecraft.world.level.newbiome.layer.traits;

public interface PixelTransformer {
   int m_77075_(int p_77076_, int p_77077_);
}