package net.minecraft.gametest.framework;

public interface GameTestListener {
   void m_8073_(GameTestInfo p_127651_);

   void m_142378_(GameTestInfo p_177494_);

   void m_8066_(GameTestInfo p_127652_);
}